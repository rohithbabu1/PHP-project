<?php 
    $severname="localhost";
    $username="root";
    $password="";
    $dbname="tech";

    $connection=new mysqli($severname, $username,$password,$dbname);

    if($connection->connect_error){
        die("connection error" . $connection->connect_error );
    };

?>