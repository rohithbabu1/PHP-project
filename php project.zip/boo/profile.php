<?php
include "outheader.php";
include "view.php";
include "footer.php";
?>