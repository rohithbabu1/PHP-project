
    
    <!-- banner section -->
    <section class="spacingb" >
        <div class="container  ">
            <div class="row banner_arrange">
                <div  class=" col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                    <h1 class="gradient-text" >
                        Techtide
                    </h1>
                    <h2 class="">
                        "Surfing the Waves of Innovation"
                    </h2>
                    <p id="banner_text">
                        Welcome to TechTide, your gateway to a world of cutting-edge technology and electronic wonders. Our mission is to empower individuals with the latest and greatest tech solutions to make life simpler, more enjoyable, and incredibly innovative.
                    </p>
                    <div class="banner_btn">
                        <button  class="swi">Shop now</button>
                    </div>
                </div>
                <div class=" col-sm-12 col-md-12 col-lg-2 col-xl-2 col-xxl-2">
                    
                </div>
                <div class=" col-sm-12 col-md-12 col-lg-4 col-xl-4 col-xxl-4">
                    <img class="img-fluid" src="./assets/Smart speaker 3d vector illustration [Converted] 1.svg" alt="banner_img">
                </div>
            </div>
           
        </div>
    </section>
    <!-- banner section -->
    <!-- exclucive section -->    
    <section class="spacing">
        <div class="container">
            <div class="row">
                <div class=" col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                    <div class="exclusive">
                        <div class="exclucive_spacing">
                            <img src="\assets\drone-01-01.svg" class="exclucive_img" alt="">
                        </div>
                        <div>
                            <span>GET UP TO 20% OFF TODAY ONLY ! </span>
                            <h3>THE 4K HDR 
                                COMPACT DRONE</h3>
                            <div> <button  class="exclucive_btn">Shop now</button>  </div> 
                        </div>   
                    </div>
                </div>
                <div class=" col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                    <div class="exclusive">
                        <div class="exclucive_spacing">
                            <img src="\assets\camera-01.svg" class="exclucive_img2" alt="exclucive_img">
                        </div>
                        <div>
                            <span>GET UP TO 20% OFF TODAY ONLY ! </span>
                            <h3>THE 4K HDR 
                                COMPACT DRONE</h3>
                            <div>
                                <button  class="exclucive_btn">Shop now</button>
                            </div> 
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- exclucive section -->
    <!-- about section -->
    <section class="spacing" id="about">
        <div class="container">
            <div class="row about ">
                <div class=" col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6">
                    <img src="assets\about us (1).svg" class=" img-fluid" alt="about_image">
                </div>
                <div class=" col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 text_arrange">
                    <h1 class="head_spacinga">
                        About
                    </h1>
                    <p>
                        Welcome to TechTide, your one-stop destination for all things e-commerce! Our journey began with a simple idea: to make online shopping a delightful and seamless experience for everyone.
    
                        At TechTide, we're passionate about curating a diverse selection of high-quality products that cater to your every need and desire. Whether you're searching for the latest fashion trends, cutting-edge tech gadgets, exquisite home decor, or everyday essentials, we've got you covered.
                        What sets us apart is our unwavering commitment to customer satisfaction. 
                    </p>
                    <div>
                        
                        <button  class="swi">Read more</button>
                    </div>
                </div>
            </div>   
        </div>
    </section>
    <!-- about section -->
    <!-- product section -->
    <section class="spacing">
        <div class="container">
            <h1 class="head_spacing">Our Products</h1>
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body hidden">
                        <img class="card-img " src="./assets/IPAD-01.svg" alt="Vans">
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Ipad</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body">
                        <div class="">
                            <img class="card-img " src="./assets/keyboard-01.svg"alt="Vans">
                        </div>
                        
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Keyboard</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body hidden">
                        <img class="card-img " src="./assets/monitor-01-01.svg"alt="Vans">
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Monitor</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body">
                        <img class="card-img " src="./assets/lap-01.svg "alt="Vans">
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Laptop</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>
        </div>


        
            <div class="row product_spacing">
                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body hidden ">
                        <img class="card-img " src="./assets/USB-01.svg" alt="Vans">
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >USB drive</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body">
                        <div class="">
                            <img class="card-img " src="./assets/mic-01.svg"alt="Vans">
                        </div>
                        
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Mic</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body hidden">
                        <img class="card-img " src="./assets/mouse-01.svg"alt="Vans">
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Mouse</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="card card_body">
                        <img class="card-img " src="./assets/Tws-01.svg "alt="Vans">
                        
                        <div class="card-body">
                            <h4 class="card-title text-center" >Air pods</h4>
                            
                            <span class="card-text text-center">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Aliquid harum maiores itaque tenetur             </span>
                            
                            <div class="buy d-flex justify-content-between align-items-center">
                                <div class="cart">
                                    <div>
                                        <h4>Rs.2999</h4>
                                        <div class="icon_sizing">
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star-fill"></i>
                                        <i class="bi bi-star"></i>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            
                                <button class="card_btn">Add cart</button>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </section>   
     <!-- product section -->
     <!-- aboutProducts -->
    <section class="spacing">
        <div class="container">
            <h1 class="head_spacing">About Our Products</h1>
            <div class="row">

                <div class=" col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al ">
                    <div class="product_card">
                        <div>
                            <img class=" ab_pr" src="assets\ba_pr_3-01.svg" alt="">
                        </div>
                        <div>
                            <h5 class="product_text pr_ab_text">High-Quality Selection:</h5>
                            
                            <span  class="pr_abtext">At TechTide, we take pride in offering a curated collection of top-notch.</span>
                        </div>
                    </div>
                </div>

                <div class=" col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3  cart_card_al">
                    <div class="product_card">
                        <div>
                            <img class=" ab_pr" src=" assets\ba_pr_1-01.svg" alt="">
                        </div>
                        <div>
                            <h5  class="product_text pr_ab_text">  User-Focused Features: </h5>
                           
                            <span  class="pr_abtext">Whether you're a professional gamer, a tech enthusiast, or simply looking to improve.</span>
                        </div>
                    </div>
                </div>

                <div class=" col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="product_card">
                        <div>
                            <img class=" ab_pr" src=" assets\ba_pr_4-01.svg" alt="">
                        </div>
                        <div>
                            <h5 class="product_text pr_ab_text">Affordability:</h5>
                            
                            <span  class="pr_abtext" >Quality shouldn't come at a high price. We strive to offer competitive prices on all our . </span>
                        </div>
                    </div>
                </div>

                <div class=" col-sm-12 col-md-6 col-lg-3 col-xl-3 col-xxl-3 cart_card_al">
                    <div class="product_card">
                        <div>
                            <img class="ab_pr" src="assets\ba_pr_3-01.svg" alt="">
                        </div>
                        <div>
                            <h5 class="product_text pr_ab_text">Durability and Reliability:</h5>
                            <span class="pr_abtext"> We understand that electronic accessories need to withstand 
                                daily use.</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- aboutProducts -->
