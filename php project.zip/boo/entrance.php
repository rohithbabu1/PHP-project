<?php
include "outheader.php";
include "content.php";
include "footer.php";


?>